from tasks.celery_config import celery

__all__ = ('celery',)
