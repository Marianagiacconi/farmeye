import socket
import threading
import json
import os
import redis
import multiprocessing
from tasks.celery_config import celery
from tasks.image_processing import process_image_task
from celery.exceptions import OperationalError
import logging
from utils.database import SessionLocal
from server.models import Image, User, Prediction

# Configuración de logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Configuración del servidor
HOST = '0.0.0.0'
PORT = 5000  
IMAGE_FOLDER = "server/uploads/"
BUFFER_SIZE = 65536  

# Configuración de Redis
REDIS_HOST = "127.0.0.1"
REDIS_PORT = 6379
redis_client = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, decode_responses=True)

def save_prediction(image_id, result, confidence):
    """Guarda la predicción en la base de datos en un proceso separado."""
    db = SessionLocal()
    try:
        prediction = Prediction(image_id=image_id, result=result, confidence=confidence)
        db.add(prediction)
        db.commit()
        logger.info(f"✅ Predicción guardada en la BD: {result} ({confidence}%)")
    except Exception as e:
        db.rollback()
        logger.error(f"❌ Error al guardar la predicción: {e}")
    finally:
        db.close()

class ImageServer:
    def __init__(self):
        self.server = None
        os.makedirs(IMAGE_FOLDER, exist_ok=True)

    def listen_for_result(self, conn, user_id, image_id):
        """Escucha el canal específico en Redis y envía el resultado al cliente."""
        channel = f"resultados:{user_id}"
        pubsub = redis_client.pubsub()
        pubsub.subscribe(channel)
        logger.info(f"📡 Cliente {user_id} suscrito a {channel}")

        for message in pubsub.listen():
            if message["type"] == "message":
                result_data = json.loads(message["data"])
                try:
                    conn.sendall(json.dumps(result_data).encode())  
                    logger.info(f"📩 Enviado resultado a {user_id}: {result_data}")
                    
                    # Guardar en la base de datos con multiproceso
                    process = multiprocessing.Process(target=save_prediction, args=(image_id, result_data["final_result"], result_data["confidence"]))
                    process.start()
                except Exception as e:
                    logger.error(f"❌ Error al enviar resultado a {user_id}: {e}")
                finally:
                    conn.close()
                    break

    def handle_client(self, conn, addr):
        """Maneja la conexión con un cliente."""
        logger.info(f"Conectado con {addr}")
        db = SessionLocal()

        try:
            size_data = conn.recv(4)
            if not size_data or len(size_data) < 4:
                raise Exception("No se recibió tamaño de metadata correctamente.")
            
            metadata_size = int.from_bytes(size_data, "big")
            metadata_bytes = conn.recv(metadata_size)
            if not metadata_bytes:
                raise Exception("No se recibió metadata.")
            
            metadata = json.loads(metadata_bytes.decode())
            action = metadata.get("action", "send_image")  # Valor por defecto para imágenes
            
            if action == "send_image":
                self.process_image_request(metadata, conn, db)
            elif action == "get_history":
                self.send_history(metadata, conn, db)
            else:
                response = {"status": "error", "message": "Acción no reconocida"}
                conn.sendall(json.dumps(response).encode())
            
        except json.JSONDecodeError as e:
            logger.error(f"❌ Error al decodificar metadata: {e}")
            conn.sendall(json.dumps({"status": "error", "message": "Error en metadata"}).encode())
        except Exception as e:
            logger.error(f"❌ Error general en handle_client: {e}")
            conn.sendall(json.dumps({"status": "error", "message": str(e)}).encode())
        finally:
            db.close()
            conn.close()

    def process_image_request(self, metadata, conn, db):
        """Procesa una solicitud de imagen."""
        user_id = int(metadata["user_id"])
        filename = metadata["image_name"]
        file_size = metadata["file_size"]
        
        logger.debug(f"📥 Recibiendo imagen {filename} ({file_size} bytes)...")

        user = db.query(User).filter_by(id=user_id).first()
        if not user:
            logger.info(f"🆕 Usuario {user_id} no encontrado. Creándolo...")
            new_user = User(id=user_id)
            db.add(new_user)
            db.commit()

        image_path = os.path.join(IMAGE_FOLDER, filename)
        received_size = 0
        with open(image_path, "wb") as f:
            while received_size < file_size:
                chunk = conn.recv(min(BUFFER_SIZE, file_size - received_size))
                if not chunk:
                    raise Exception("Conexión interrumpida")
                f.write(chunk)
                received_size += len(chunk)
                conn.sendall(b"ACK")

        logger.info(f"✅ Imagen guardada en {image_path}")

        new_image = Image(image_path=image_path, user_id=user_id)
        db.add(new_image)
        db.commit()
        logger.debug(f"📝 Imagen registrada en BD con ID: {new_image.id}")

        try:
            task = process_image_task.delay(image_path, user_id)
            logger.debug(f"🚀 Tarea enviada a Celery con ID: {task.id}")
            response = {"status": "success", "task_id": task.id, "image_path": image_path, "message": "Imagen recibida y procesamiento iniciado"}
            conn.sendall(json.dumps(response).encode())

            # Iniciar hilo para recibir el resultado
            listener_thread = threading.Thread(target=self.listen_for_result, args=(conn, user_id, new_image.id))
            listener_thread.daemon = True
            listener_thread.start()
        except OperationalError as e:
            logger.error(f"⚠️ Error con Celery/Redis: {e}")
            conn.sendall(json.dumps({"status": "error", "error": "Error de conexión con el sistema de procesamiento", "details": str(e)}).encode())
        except Exception as e:
            logger.error(f"❌ Error inesperado al procesar imagen: {e}")
            conn.sendall(json.dumps({"status": "error", "error": "Error interno del servidor", "details": str(e)}).encode())

    def send_history(self, metadata, conn, db):
        """Consulta el historial de predicciones de un usuario y lo envía al cliente."""
        user_id = int(metadata["user_id"])

        predictions = db.query(Prediction).join(Image).filter(Image.user_id == user_id).all()
        history = [{"image_id": p.image_id, "result": p.result, "confidence": p.confidence} for p in predictions]

        response = {"status": "success", "historial": history}
        conn.sendall(json.dumps(response).encode())
        logger.info(f"📜 Historial enviado al usuario {user_id}")

    def start(self):
        """Inicia el servidor TCP y maneja múltiples clientes con threads."""
        try:
            self.server = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
            self.server.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
            self.server.bind(("::", PORT))
            self.server.listen(5)
            logger.info(f"🚀 Servidor TCP iniciado en {HOST}:{PORT}")
            while True:
                conn, addr = self.server.accept()
                client_thread = threading.Thread(target=self.handle_client, args=(conn, addr))
                client_thread.daemon = True
                client_thread.start()
        except Exception as e:
            logger.error(f"❌ Error al iniciar servidor: {e}")
        finally:
            if self.server:
                self.server.close()

if __name__ == "__main__":
    server = ImageServer()
    try:
        server.start()
    except KeyboardInterrupt:
        logger.info("🛑 Deteniendo servidor...")
        server.server.close()
